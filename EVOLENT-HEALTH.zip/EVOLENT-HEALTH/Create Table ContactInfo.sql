--USE [POONAM]

CREATE TABLE [dbo].[ContactInfo](
	[ID] [int] IDENTITY(1,1) Primary Key,
	[FirstName] [varchar](100) NOT NULL,
	[LastName] [varchar](100) NOT NULL,
	[Email] [nvarchar](320),
	[Phone] [varchar](22),
	[Status] [bit] NOT NULL,
	[CreatedBy] [varchar] (250),
	[CreadedDate] DateTime Default GetDate(),
	[ModifiedBy] [varchar] (250),
	[ModifiedDate] DateTime Default GetDate()
) 

GO
--Drop table ContactInfo