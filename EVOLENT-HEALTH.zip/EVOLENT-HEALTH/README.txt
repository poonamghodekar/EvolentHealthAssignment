1) Run the DB script for creating the ContactInfo table from filename - Create Table ContactInfo.sql

2) There are 2 separate solutions provided one for Restful service(EvolentHealthRESTService, present in folder "WebApi") and another for Web Application (EvolentHealthWebProtal).

3) Here we Need to change db connectionstring in "EvolentHealthRESTService" application for project  "Evolent.Health.DataModel" in "App.config" file.

  <connectionStrings>
    <add name="EvolentHealthDbEntities" connectionString="metadata=res://*/EvolentHealthDataModel.csdl|res://*/EvolentHealthDataModel.ssdl|res://*/EvolentHealthDataModel.msl;provider=System.Data.SqlClient;provider connection string=&quot;data source=SACHIN-PC\SQLEXPRESS;initial catalog=POONAM;integrated security=True;multipleactiveresultsets=True;App=EntityFramework&quot;" providerName="System.Data.EntityClient" />
  </connectionStrings>

4) Do the same thing of point no 3, i.e change connection string for Project "Evolent.Health.WebApi" in "Web.config" file.

<connectionStrings>
    <add name="EvolentHealthDbEntities" connectionString="metadata=res://*/EvolentHealthDataModel.csdl|res://*/EvolentHealthDataModel.ssdl|res://*/EvolentHealthDataModel.msl;provider=System.Data.SqlClient;provider connection string=&quot;data source=SACHIN-PC\SQLEXPRESS;initial catalog=POONAM;integrated security=True;multipleactiveresultsets=True;App=EntityFramework&quot;" providerName="System.Data.EntityClient" />
  </connectionStrings>

5) Now, First Run the "EvolentHealthRESTService" Application locally.

6) Now in "EvolentHealthWebProtal" application for project "Evolent.Health.DAL" change web API URL hosted locally in point no.5

    Change the below given "baseURL" in "ContactDetailsDAL()" constructor.

        public ContactDetailsDAL()
        {
            baseURL = "http://localhost:1437/";
        }